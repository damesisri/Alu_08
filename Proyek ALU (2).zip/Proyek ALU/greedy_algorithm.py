#!/usr/bin/env python
# coding: utf-8

# In[4]:


# Greedy Algorithm
def greedy_algorithm(distance_matrix, start_node):
    num_nodes = len(distance_matrix)
    visited_nodes = set()
    current_node = start_node
    path = [current_node]

    while len(visited_nodes) < num_nodes:
        next_node = min(
            (node for node in range(num_nodes) if node not in visited_nodes),
            key=lambda x: distance_matrix[current_node][x]
        )
        visited_nodes.add(next_node)
        path.append(next_node)
        current_node = next_node

    return path


# Matriks jarak
distance_matrix = [
    [0, 1.2, 1, 1.2],
    [1.2, 0, 0.6, 1.4],
    [1, 0.6, 0, 1.2],
    [1.2, 1.5, 1.2, 0]
]

# Daftar tempat
places = [
    "RS HKBP Balige",
    "Pelabuhan Penyebrangan Balige",
    "Gereja Katolik Balige",
    "Telkom Balige"
]

# Jalur antar tempat
routes = {
    "RS HKBP Balige": {
        "Pelabuhan Penyebrangan Balige": ["Jl. Gereja", "Jl. Gereja -> Jl. Lintas Sumatera", "Jl. Raja Paindoan"],
        "Gereja Katolik Balige": ["Jl. Gereja, Jl. Lintas Sumatera -> Jl. Patuan Nagari", "Jl. Gereja -> Jl. Lintas Sumatera"],
        "Telkom Balige": ["Jl. Gereja", "Jl. Raja Paindoan"]
    },
    "Pelabuhan Penyebrangan Balige": {
        "RS HKBP Balige": ["Jl. Gereja", "Jl. Gereja -> Jl. Lintas Sumatera", "Jl. Raja Paindoan"],
        "Gereja Katolik Balige": ["Jl. Bukit Barisan -> Jl. Siliwangi -> Jl. Pdt. Leman", "Jl. Bukit Barisan -> Jl. Dr. T.D. Pardede -> dan Jl. Lintas Sumatera"],
        "Telkom Balige": ["Jl. Gereja", "Jl. GHM. Siahaan"]
    },
    "Gereja Katolik Balige": {
        "RS HKBP Balige": ["Jl. Gereja, Jl. Lintas Sumatera -> Jl. Patuan Nagari", "Jl. Gereja -> Jl. Lintas Sumatera"],
        "Pelabuhan Penyebrangan Balige": ["Jl. Bukit Barisan -> Jl. Siliwangi -> Jl. Pdt. Leman", "Jl. Bukit Barisan -> Jl. Dr. T.D. Pardede -> dan Jl. Lintas Sumatera"],
        "Telkom Balige": ["Jl. Lintas Sumatera", "Jl. Lintas Sumatera -> Jl. Gereja"]
    },
    "Telkom Balige": {
        "RS HKBP Balige": ["Jl. Gereja", "Jl. Raja Paindoan"],
        "Pelabuhan Penyebrangan Balige": ["Jl. Gereja", "Jl. GHM. Siahaan"],
        "Gereja Katolik Balige": ["Jl. Lintas Sumatera", "Jl. Lintas Sumatera -> Jl. Gereja"]
    }
}

# Menambahkan jarak khusus ke matriks jarak (misalnya, RS HKBP Balige ke Telkom Balige)
special_distance_RS_to_Telkom = 1.5
special_distance_Telkom_to_RS = 1.2
RS_index = places.index("RS HKBP Balige")
Telkom_index = places.index("Telkom Balige")
distance_matrix[RS_index][Telkom_index] = special_distance_RS_to_Telkom
distance_matrix[Telkom_index][RS_index] = special_distance_Telkom_to_RS

# Menentukan jalur awal (misalnya, RS HKBP Balige ke Pelabuhan Penyebrangan Balige)
start_place = "RS HKBP Balige"
end_place = "Pelabuhan Penyebrangan Balige"
start_index = places.index(start_place)
end_index = places.index(end_place)

result_path = greedy_algorithm(distance_matrix, start_index)
print("Jalur terpendek:", result_path)

# Menemukan jalur spesifik antara tempat awal dan akhir
route_description = routes[start_place][end_place]
print("Rute terpendek:", route_description)


# In[ ]:




