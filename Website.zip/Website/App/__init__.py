from flask import Flask

App = Flask()

from App import routes 